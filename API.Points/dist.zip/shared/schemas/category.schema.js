"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const base_schema_1 = require("./base.schema");
exports.CategorySchema = base_schema_1.BaseSchema({
    name: { type: String, required: true, unique: true }
});
