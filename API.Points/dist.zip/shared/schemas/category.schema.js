"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategorySchema = void 0;
const base_schema_1 = require("./base.schema");
exports.CategorySchema = base_schema_1.BaseSchema({
    name: { type: String, required: true, unique: true },
    disabled: { type: Boolean, default: false }
});
