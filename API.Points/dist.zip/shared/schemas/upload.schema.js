"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadSchema = void 0;
const base_schema_1 = require("./base.schema");
const mongoose_1 = require("mongoose");
exports.UploadSchema = base_schema_1.BaseSchema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true },
    photo: { type: String, required: true },
    title: { type: String },
    description: { type: String }
});
