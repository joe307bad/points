"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckinSchema = void 0;
const base_schema_1 = require("./base.schema");
const mongoose_1 = require("mongoose");
exports.CheckinSchema = base_schema_1.BaseSchema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true },
    achievementId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Achievement', required: true },
    approved: { type: Boolean, required: true, default: false },
    photo: { type: String }
});
