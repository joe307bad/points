"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
exports.BaseSchema = (definition) => {
    return new mongoose.Schema(definition, {
        timestamps: true,
        toJSON: {
            virtuals: true
        },
    });
};
