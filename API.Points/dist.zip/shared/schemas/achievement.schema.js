"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AchievementSchema = void 0;
const base_schema_1 = require("./base.schema");
const mongoose_1 = require("mongoose");
exports.AchievementSchema = base_schema_1.BaseSchema({
    name: { type: String, required: true, unique: true },
    categoryId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Category', required: true },
    points: { type: Number, required: true },
    description: { type: String, required: true, text: true },
    photo: { type: String }
});
exports.AchievementSchema.index({
    name: 'text',
    description: 'text'
});
exports.AchievementSchema.virtual('checkins', {
    ref: 'Checkin',
    localField: '_id',
    foreignField: 'achievementId'
});
