"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ApprovalDto {
}
exports.ApprovalDto = ApprovalDto;
