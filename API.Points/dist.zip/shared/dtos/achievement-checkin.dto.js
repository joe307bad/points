"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const achievement_dto_1 = require("./achievement.dto");
class AchievementCheckinDto extends achievement_dto_1.AchievementDto {
}
exports.AchievementCheckinDto = AchievementCheckinDto;
