"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const bcrypt = require("bcrypt");
let SeedService = class SeedService {
    constructor(userModel, achievementModel, categoryModel) {
        this.userModel = userModel;
        this.achievementModel = achievementModel;
        this.categoryModel = categoryModel;
    }
    seed(data) {
        return __awaiter(this, void 0, void 0, function* () {
            const categories = yield this.seedCategories(data.categories);
            const achievements = yield this.seedAchievements(data.achievements, categories);
            const users = yield this.seedUsers(data.admins);
            return {
                categories: categories.length,
                achievements: achievements.length,
                users: users.length
            };
        });
    }
    seedCategories(categories) {
        return __awaiter(this, void 0, void 0, function* () {
            const allCategories = yield this.categoryModel.find({});
            const existingCategories = [];
            const missingCategories = categories
                .filter(category => !allCategories.find(savedCategory => {
                const categoryExists = savedCategory.name.toLowerCase() === category.name.toLowerCase();
                if (categoryExists) {
                    existingCategories.push(savedCategory);
                }
                return categoryExists;
            }));
            const categoryAudit = {
                missing: missingCategories,
                existing: existingCategories
            };
            let newlyAddedCategories = [];
            if (categoryAudit.missing.length) {
                newlyAddedCategories = yield this.categoryModel.insertMany(categoryAudit.missing);
            }
            return [...newlyAddedCategories, ...categoryAudit.existing];
        });
    }
    seedAchievements(achievements, categories) {
        return __awaiter(this, void 0, void 0, function* () {
            const allAchievements = yield this.achievementModel.find({});
            const existingAchievements = [];
            const missingAchievements = achievements
                .filter(achievement => !allAchievements.find(savedAchievement => {
                const achievementExists = savedAchievement.name.toLowerCase() === achievement.name.toLowerCase();
                if (achievementExists) {
                    existingAchievements.push(Object.assign(Object.assign({}, achievement), { id: savedAchievement.id }));
                }
                return achievementExists;
            }));
            const achievementAudit = {
                missing: missingAchievements.map(achievement => {
                    const achievementCategory = categories
                        .find(category => achievement.category.toLowerCase() === category.name.toLowerCase());
                    achievement.categoryId = achievementCategory.id;
                    return achievement;
                }),
                existing: existingAchievements
            };
            let newlyAddedAchievements = [];
            let editedAchievements = [];
            if (achievementAudit.missing.length) {
                newlyAddedAchievements = yield this.achievementModel.insertMany(achievementAudit.missing);
            }
            if (achievementAudit.existing.length) {
                editedAchievements = yield achievementAudit.existing.reduce((acc, a) => __awaiter(this, void 0, void 0, function* () {
                    const category = yield this.categoryModel.findOne({ name: a.category });
                    return acc.then((p) => __awaiter(this, void 0, void 0, function* () {
                        return [
                            ...p,
                            yield this.achievementModel.update({ _id: a.id }, Object.assign(Object.assign({}, a), { categoryId: category.id }))
                        ];
                    }));
                }), Promise.resolve([]));
            }
            return [...newlyAddedAchievements, ...achievementAudit.existing];
        });
    }
    seedUsers(users) {
        return __awaiter(this, void 0, void 0, function* () {
            const allUsers = yield this.userModel.find({});
            const existingUsers = [];
            const missingUsers = users
                .filter(user => !allUsers.find(savedUser => {
                const userExists = savedUser.userName.toLowerCase() === user.userName.toLowerCase();
                if (userExists) {
                    existingUsers.push(savedUser);
                }
                return userExists;
            }));
            const userAudit = {
                missing: missingUsers.map(user => {
                    const userWithPassword = Object.assign(user, { password: bcrypt.hashSync(user.password, 10) });
                    return userWithPassword;
                }),
                existing: existingUsers
            };
            let newlyAddedUsers = [];
            if (userAudit.missing.length) {
                newlyAddedUsers = yield this.userModel.insertMany(userAudit.missing);
            }
            return [...newlyAddedUsers, ...userAudit.existing];
        });
    }
};
SeedService = __decorate([
    common_1.Injectable(),
    __param(0, common_1.Inject('User')),
    __param(1, mongoose_1.InjectModel('Achievement')),
    __param(2, mongoose_1.InjectModel('Category')),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model,
        mongoose_2.Model])
], SeedService);
exports.SeedService = SeedService;
