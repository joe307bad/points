"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const common_1 = require("@nestjs/common");
const bcrypt = require("bcrypt");
const shared_1 = require("@points/shared");
const _1 = require("../core/mongo/");
const auth_1 = require("../auth");
let UserService = class UserService {
    constructor(userModel, auth) {
        this.userModel = userModel;
        this.auth = auth;
        this.db = _1.DatabaseService;
    }
    create(userDto) {
        return __awaiter(this, void 0, void 0, function* () {
            userDto = Object.assign(userDto, { userName: userDto.userName.toLowerCase(), roles: undefined });
            const user = new this.userModel(userDto);
            return this.db.save(user).then(newUser => this.auth.createToken(newUser));
        });
    }
    login(userDto) {
        return __awaiter(this, void 0, void 0, function* () {
            const userData = yield this.findByUserName(userDto.userName);
            return bcrypt.compare(userDto.password, userData.password)
                .then(res => res
                ? this.auth.createToken(userData)
                : Promise.reject(new shared_1.ApiError('Incorrect password')));
        });
    }
    exists(user) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.userModel.count({ userName: user.userName.toLowerCase() })
                .then(numberOfUsers => numberOfUsers > 0);
        });
    }
    findByUserName(userName) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.userModel.findOne({ userName }).select('+password');
        });
    }
    update(user, params) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve(new shared_1.ApiError('Method not implemented.'));
        });
    }
};
UserService = __decorate([
    common_1.Injectable(),
    __param(0, common_1.Inject('User')),
    __metadata("design:paramtypes", [mongoose_1.Model,
        auth_1.AuthService])
], UserService);
exports.UserService = UserService;
