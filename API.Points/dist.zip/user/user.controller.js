"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const shared_1 = require("@points/shared");
const user_service_1 = require("./user.service");
const acl_1 = require("../core/acl");
const app_settings_1 = require("../app.settings");
const resource = 'user';
const to = (action) => new acl_1.ApiPermission(action, resource, 'id', 'objectId');
let UserController = class UserController {
    constructor(user) {
        this.user = user;
    }
    create(user, photo) {
        return __awaiter(this, void 0, void 0, function* () {
            user.photo = photo ? photo.filename : null;
            return yield this.user.create(user).catch(err => err);
        });
    }
    login(user) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.user.login(user).catch(err => err);
        });
    }
    update(user, params) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve(new shared_1.ApiError('Not Implemented'));
        });
    }
};
__decorate([
    common_1.Post(),
    common_1.UseInterceptors(common_1.FileInterceptor('photo', app_settings_1.UploadFileSettings)),
    __param(0, common_1.Body()), __param(1, common_1.UploadedFile()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [shared_1.UserDto, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "create", null);
__decorate([
    common_1.Post('login'),
    __param(0, common_1.Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [shared_1.UserDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "login", null);
__decorate([
    common_1.Put(':id'),
    common_1.UseGuards(passport_1.AuthGuard('jwt')),
    acl_1.HasPermission(to('update')),
    __param(0, common_1.Body()), __param(1, common_1.Param()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [shared_1.UserDto, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "update", null);
UserController = __decorate([
    common_1.Controller(resource),
    common_1.UseGuards(acl_1.PermissionGaurd),
    __metadata("design:paramtypes", [user_service_1.UserService])
], UserController);
exports.UserController = UserController;
