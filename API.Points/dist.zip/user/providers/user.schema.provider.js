"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserSchemaProvider = void 0;
const bcrypt = require("bcrypt");
const schemas_1 = require("../../shared/schemas");
exports.UserSchemaProvider = {
    provide: 'User',
    useFactory: (connection, access) => {
        const roles = access.getRoles();
        const UserSchema = schemas_1.BaseSchema({
            firstName: { type: String, required: true },
            lastName: { type: String, required: true },
            userName: { type: String, unique: true, required: true },
            password: { type: String, required: true, select: false },
            passwordReset: { type: Boolean, default: true },
            roles: {
                type: [{ type: String, enum: roles }],
                default: 'user',
                required: true
            },
            approved: { type: Boolean, required: true, default: false },
            photo: { type: String }
        });
        UserSchema.virtual('checkins', {
            ref: 'Checkin',
            localField: '_id',
            foreignField: 'userId'
        });
        UserSchema.pre('save', function (next) {
            const user = this;
            if (user.password) {
                bcrypt.hash(user.password, 10, function (err, hash) {
                    if (err) {
                        return next(err);
                    }
                    user.password = hash;
                    next();
                });
            }
        });
        UserSchema.pre('findOneAndUpdate', function (next) {
            const context = this;
            let password = this.getUpdate().password;
            let passwordReset = this.getUpdate().passwordReset;
            if (password) {
                bcrypt.hash(password, 10, function (err, hash) {
                    if (err) {
                        return next(err);
                    }
                    password = hash;
                    if (passwordReset === true) {
                        context._update.passwordReset = true;
                    }
                    else {
                        context._update.passwordReset = false;
                    }
                    context._update.password = password;
                    next();
                });
            }
            else {
                next();
            }
        });
        return connection.model('User', UserSchema);
    },
    inject: ['DBConnection', 'AccessControl']
};
