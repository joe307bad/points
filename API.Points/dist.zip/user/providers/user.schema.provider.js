"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const schemas_1 = require("../../shared/schemas");
exports.UserSchemaProvider = {
    provide: 'User',
    useFactory: (access) => {
        const roles = access.getRoles();
        const UserSchema = schemas_1.BaseSchema({
            firstName: { type: String, required: true },
            lastName: { type: String, required: true },
            userName: { type: String, unique: true, required: true },
            password: { type: String, required: true, select: false },
            roles: { type: [{ type: String, enum: roles }], default: 'user', required: true },
            photo: { type: String }
        });
        UserSchema.virtual('checkins', {
            ref: 'Checkin',
            localField: '_id',
            foreignField: 'userId'
        });
        UserSchema.pre('save', function (next) {
            const user = this;
            if (user.password) {
                bcrypt.hash(user.password, 10, function (err, hash) {
                    if (err) {
                        return next(err);
                    }
                    user.password = hash;
                    next();
                });
            }
        });
        return mongoose.model('User', UserSchema);
    },
    inject: ['AccessControl']
};
