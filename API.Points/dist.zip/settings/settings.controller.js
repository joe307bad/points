"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsController = exports.to = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const ac = require("accesscontrol");
const acl_1 = require("../core/acl");
const settings_service_1 = require("./settings.service");
const resource = 'settings';
exports.to = (action) => new acl_1.ApiPermission(action, resource);
let SettingsController = class SettingsController {
    constructor(settings, access) {
        this.settings = settings;
        this.access = access;
    }
    get(req) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = acl_1.decodeToken(req);
            const permission = this.access.can(user.roles).readAny('settings');
            return yield this.settings.get().then(settings => permission.filter(settings));
        });
    }
};
__decorate([
    common_1.Get(),
    acl_1.HasPermission(exports.to('read')),
    __param(0, common_1.Req()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SettingsController.prototype, "get", null);
SettingsController = __decorate([
    common_1.Controller(resource),
    common_1.UseGuards(passport_1.AuthGuard('jwt'), acl_1.PermissionGaurd),
    __metadata("design:paramtypes", [settings_service_1.SettingsService, ac.AccessControl])
], SettingsController);
exports.SettingsController = SettingsController;
