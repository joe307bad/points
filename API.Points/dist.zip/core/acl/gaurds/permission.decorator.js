"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
exports.HasPermission = (permission) => common_1.ReflectMetadata('permission', permission);
