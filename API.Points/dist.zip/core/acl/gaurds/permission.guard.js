"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const ac = require("accesscontrol");
const helpers_1 = require("../helpers");
const app_settings_1 = require("../../../app.settings");
let PermissionGaurd = class PermissionGaurd {
    constructor(reflector, access) {
        this.reflector = reflector;
        this.access = access;
    }
    canActivate(context) {
        const intent = this.reflector.get('permission', context.getHandler());
        if (!intent) {
            return true;
        }
        const request = context.switchToHttp().getRequest();
        const response = context.switchToHttp().getResponse();
        response.header(app_settings_1.ApiIntentHeader, JSON.stringify(intent));
        const user = helpers_1.decodeToken(request);
        if (!user || !user.roles) {
            return false;
        }
        let own = false;
        const hasBody = !!request.body && !!Object.keys(request.body).length;
        if (!hasBody && !Object.keys(request.params).length) {
            return true;
        }
        const roles = user.roles;
        const permission = (action, owned) => (this.access.can(roles))[action + (owned ? 'Own' : '')](intent.resource);
        if (hasBody) {
            if (!!request.params && !!request.params.id) {
                request.body.id = request.params.id;
            }
            own = intent.ownId ? intent.owned(request.body, user.id) : false;
            request.body = permission(intent.action, own).filter(request.body);
        }
        response.header(app_settings_1.OwnsHeader, own);
        return permission(intent.action, own).granted;
    }
};
PermissionGaurd = __decorate([
    common_1.Injectable(),
    __metadata("design:paramtypes", [core_1.Reflector, ac.AccessControl])
], PermissionGaurd);
exports.PermissionGaurd = PermissionGaurd;
