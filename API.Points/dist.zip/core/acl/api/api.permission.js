"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiPermission = void 0;
class ApiPermission {
    constructor(action, resource, ownId, ownType) {
        this.action = action;
        this.resource = resource;
        this.ownId = ownId;
        this.ownType = ownType;
    }
    owned(entity, userId) {
        switch (this.ownType) {
            case 'objectId':
                return entity[this.ownId] === userId;
        }
    }
}
exports.ApiPermission = ApiPermission;
