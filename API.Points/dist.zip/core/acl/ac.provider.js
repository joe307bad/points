"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ac = require("accesscontrol");
exports.AcProvider = {
    provide: 'AccessControl',
    useFactory: () => {
        const grants = {
            admin: {
                user: {
                    'read:any': ['*'],
                    'create:any': ['*'],
                    'update:any': ['*']
                },
                achievement: {
                    'read:any': ['*'],
                    'create:any': ['*'],
                    'update:any': ['*']
                },
                checkin: {
                    'read:any': ['*'],
                    'update:any': ['*'],
                    'create:any': ['*'],
                    'delete:any': ['*']
                },
                upload: {
                    'read:any': ['*'],
                    'update:any': ['*'],
                    'create:any': ['*'],
                    'delete:any': ['*']
                },
                category: {
                    'read:any': ['*'],
                    'update:any': ['*'],
                    'create:any': ['*'],
                    'delete:any': ['*']
                },
                settings: {
                    'read:any': ['*'],
                    'update:any': ['*'],
                    'create:any': ['*'],
                    'delete:any': ['*']
                }
            },
            user: {
                user: {
                    'read:any': ['*', '!password'],
                    'update:own': ['*'],
                    'delete:own': ['*']
                },
                achievement: {
                    'read:any': ['*']
                },
                checkin: {
                    'read:any': ['*'],
                    'update:own': ['*', '!approved'],
                    'create:own': ['*'],
                    'delete:own': ['*']
                },
                upload: {
                    'read:any': ['*'],
                    'update:own': ['*'],
                    'create:own': ['*'],
                    'delete:own': ['*']
                },
                category: {
                    'read:any': ['*']
                },
                settings: {
                    'read:any': ['*', '!navigation.controlPanel'],
                    'update:own': ['*'],
                    'create:own': ['*'],
                    'delete:own': ['*']
                }
            }
        };
        return new ac.AccessControl(grants);
    },
};
