"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isAdmin = void 0;
const decodeToken_helper_1 = require("./decodeToken.helper");
function isAdmin(request) {
    const user = decodeToken_helper_1.decodeToken(request);
    return user.roles.some(role => role === "admin");
}
exports.isAdmin = isAdmin;
