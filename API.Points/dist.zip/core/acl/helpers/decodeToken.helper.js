"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jwt = require("jsonwebtoken");
function decodeToken(request) {
    const token = !!request.headers && !!request.headers.authorization
        ? request.headers.authorization.split(' ')[1]
        : null;
    return !!token ? jwt.decode(token) : null;
}
exports.decodeToken = decodeToken;
