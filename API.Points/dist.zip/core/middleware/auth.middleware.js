"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const tamper = require("tamper");
const accesscontrol_1 = require("accesscontrol");
const acl_1 = require("../acl");
let AuthMiddleware = class AuthMiddleware {
    constructor(access) {
        this.access = access;
    }
    resolve(...args) {
        const context = this;
        return tamper(function (req, res) {
            if (res.getHeader('Content-Type') !== 'application/json; charset=utf-8') {
                return;
            }
            return function (body) {
                const user = acl_1.decodeToken(req);
                let intent = res.getHeader('X-Api-Intent');
                let owned = res.getHeader('X-Owns-Resource');
                if (intent && user && user.roles) {
                    intent = JSON.parse(intent);
                    const roles = user.roles;
                    owned = owned === 'true';
                    const permission = (context.access.can(roles))[intent.action + (owned ? 'Own' : '')](intent.resource);
                    if (!permission.granted) {
                        return body;
                    }
                    body = JSON.parse(body);
                    body = permission.filter(body);
                    body = JSON.stringify(body);
                }
                return body;
            };
        });
    }
};
AuthMiddleware = __decorate([
    common_1.Injectable(),
    __metadata("design:paramtypes", [accesscontrol_1.AccessControl])
], AuthMiddleware);
exports.AuthMiddleware = AuthMiddleware;
