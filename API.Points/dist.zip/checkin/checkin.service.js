"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("@nestjs/mongoose");
const common_1 = require("@nestjs/common");
const mongoose_2 = require("mongoose");
const mongodb_1 = require("mongodb");
const mongo_1 = require("../core/mongo");
let CheckinService = class CheckinService {
    constructor(checkinModel, userModel, achievementModel, categoryModel) {
        this.checkinModel = checkinModel;
        this.userModel = userModel;
        this.achievementModel = achievementModel;
        this.categoryModel = categoryModel;
        this.db = mongo_1.DatabaseService;
    }
    create(checkinDto) {
        return __awaiter(this, void 0, void 0, function* () {
            const checkin = new this.checkinModel(checkinDto);
            return this.db.save(checkin);
        });
    }
    getForUser(user) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.buildUserCheckinAggregate(true, user.userId)
                .then(userCheckins => userCheckins[0]);
        });
    }
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.buildUserCheckinAggregate(true);
        });
    }
    getFeed() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.buildFeedAggregate();
        });
    }
    getPendingApprovals() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.buildCheckinAggregate();
        });
    }
    getLeaderboard() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.buildUserCheckinAggregate();
        });
    }
    update(checkinDto) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.checkinModel
                .findByIdAndUpdate({ _id: checkinDto.id }, checkinDto, { new: true });
        });
    }
    delete(checkinDto) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.checkinModel.deleteOne({ _id: checkinDto.id });
        });
    }
    buildFeedAggregate() {
        let pipeline = [];
        pipeline = [...pipeline,
            {
                '$match': {
                    'approved': true
                }
            }, {
                '$lookup': {
                    'from': this.achievementModel.collection.name,
                    'localField': 'achievementId',
                    'foreignField': '_id',
                    'as': 'achievements'
                }
            }, {
                '$lookup': {
                    'from': this.userModel.collection.name,
                    'localField': 'userId',
                    'foreignField': '_id',
                    'as': 'users'
                }
            },
            {
                '$lookup': {
                    'from': this.categoryModel.collection.name,
                    'localField': 'achievements.categoryId',
                    'foreignField': '_id',
                    'as': 'categories'
                }
            },
            { '$sort': { 'createdAt': -1 } },
            {
                '$project': {
                    'checkinId': '$$ROOT._id',
                    'userId': { $arrayElemAt: ['$users._id', 0] },
                    'userName': { $arrayElemAt: ['$users.userName', 0] },
                    'achievementName': { $arrayElemAt: ['$achievements.name', 0] },
                    'achievementDescription': { $arrayElemAt: ['$achievements.description', 0] },
                    'category': { $arrayElemAt: ['$categories.name', 0] },
                    'points': { $arrayElemAt: ['$achievements.points', 0] },
                    'checkinDate': '$$ROOT.createdAt'
                }
            }
        ];
        return this.checkinModel.aggregate(pipeline).exec();
    }
    buildCheckinAggregate() {
        let pipeline = [];
        pipeline = [...pipeline,
            {
                '$match': {
                    'approved': false
                }
            }, {
                '$lookup': {
                    'from': this.achievementModel.collection.name,
                    'localField': 'achievementId',
                    'foreignField': '_id',
                    'as': 'achievements'
                }
            }, {
                '$lookup': {
                    'from': this.userModel.collection.name,
                    'localField': 'userId',
                    'foreignField': '_id',
                    'as': 'users'
                }
            },
            { '$sort': { 'createdAt': -1 } },
            {
                '$project': {
                    'checkinId': '$$ROOT._id',
                    'userName': { $arrayElemAt: ['$users.userName', 0] },
                    'achievementName': { $arrayElemAt: ['$achievements.name', 0] },
                    'points': { $arrayElemAt: ['$achievements.points', 0] },
                    'checkinDate': '$$ROOT.createdAt'
                }
            }];
        return this.checkinModel.aggregate(pipeline).exec();
    }
    buildUserCheckinAggregate(withAchievements = false, userId) {
        let pipeline = [];
        const grouping = {
            '$group': {
                '_id': '$_id',
                'userId': { '$first': '$_id' },
                'userName': { '$first': '$userName' },
                'firstName': { '$first': '$firstName' },
                'totalCheckins': { '$sum': 1 },
                'totalPoints': { '$sum': '$achievements.approvedPoints' },
                'pendingPoints': { '$sum': '$achievements.pendingPoints' },
            }
        };
        if (!!userId) {
            pipeline = [...pipeline,
                {
                    '$match': {
                        '_id': new mongodb_1.ObjectId(userId)
                    }
                }];
        }
        pipeline = [...pipeline,
            {
                '$lookup': {
                    'from': this.checkinModel.collection.name,
                    'localField': '_id',
                    'foreignField': 'userId',
                    'as': 'checkins'
                }
            },
            { '$unwind': '$checkins' },
            {
                '$lookup': {
                    'from': this.achievementModel.collection.name,
                    'localField': 'checkins.achievementId',
                    'foreignField': '_id',
                    'as': 'achievements'
                }
            },
            { '$unwind': '$achievements' },
            {
                '$addFields': {
                    'achievements.approvedPoints': {
                        $cond: {
                            if: {
                                $eq: ['$checkins.approved', true]
                            },
                            then: '$achievements.points',
                            else: 0
                        }
                    },
                    'achievements.pendingPoints': {
                        $cond: {
                            if: {
                                $eq: ['$checkins.approved', false]
                            },
                            then: '$achievements.points',
                            else: 0
                        }
                    }
                }
            }];
        if (withAchievements) {
            pipeline = [...pipeline,
                {
                    '$addFields': {
                        'achievements.checkinDate': '$checkins.createdAt',
                        'achievements.approved': '$checkins.approved',
                        'achievements.achievementId': '$achievements._id',
                        'achievements.checkinId': '$checkins._id'
                    }
                }];
            grouping['$group']['checkins'] = { '$push': '$achievements' };
        }
        pipeline = [...pipeline, grouping, { '$sort': { 'totalPoints': -1 } }];
        return this.userModel.aggregate(pipeline).exec();
    }
};
CheckinService = __decorate([
    common_1.Injectable(),
    __param(0, mongoose_1.InjectModel('Checkin')),
    __param(1, common_1.Inject('User')),
    __param(2, mongoose_1.InjectModel('Achievement')),
    __param(3, mongoose_1.InjectModel('Category')),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model,
        mongoose_2.Model,
        mongoose_2.Model])
], CheckinService);
exports.CheckinService = CheckinService;
