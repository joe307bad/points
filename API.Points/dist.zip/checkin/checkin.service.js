"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckinService = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const common_1 = require("@nestjs/common");
const mongoose_2 = require("mongoose");
const mongo_1 = require("../core/mongo");
const pipelines_1 = require("./pipelines");
const pendingApprovals_pipeline_1 = require("./pipelines/pendingApprovals.pipeline");
const feed_pipeline_1 = require("./pipelines/feed.pipeline");
let CheckinService = class CheckinService {
    constructor(checkinModel, userModel) {
        this.checkinModel = checkinModel;
        this.userModel = userModel;
        this.db = mongo_1.DatabaseService;
    }
    create(checkinDto) {
        return __awaiter(this, void 0, void 0, function* () {
            const checkin = new this.checkinModel(checkinDto);
            return this.db.save(checkin);
        });
    }
    getForUser(user) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.userModel.aggregate(pipelines_1.userWithCheckinsPipeline(user.userId)).exec().then(users => users[0] || {});
        });
    }
    getFeed() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.checkinModel.aggregate(feed_pipeline_1.feedPipeline()).exec();
        });
    }
    getPendingApprovals() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.checkinModel.aggregate(pendingApprovals_pipeline_1.pendingApprovalsPipeline()).exec();
        });
    }
    getLeaderboard() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.userModel.aggregate(pipelines_1.leaderboardPipeline()).exec();
        });
    }
    update(checkinDto) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.checkinModel.findByIdAndUpdate({ _id: checkinDto.id }, checkinDto, { new: true });
        });
    }
    delete(checkin) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.checkinModel.deleteOne({ _id: checkin.id });
        });
    }
};
CheckinService = __decorate([
    common_1.Injectable(),
    __param(0, mongoose_1.InjectModel('Checkin')),
    __param(1, common_1.Inject('User')),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model])
], CheckinService);
exports.CheckinService = CheckinService;
