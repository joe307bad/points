"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userWithCheckinsPipeline = void 0;
const app_settings_1 = require("../../app.settings");
const mongodb_1 = require("mongodb");
function userWithCheckinsPipeline(userId) {
    return [
        {
            $match: {
                _id: new mongodb_1.ObjectId(userId)
            }
        },
        {
            $lookup: {
                from: 'checkins',
                localField: '_id',
                foreignField: 'userId',
                as: 'checkins'
            }
        },
        {
            $unwind: {
                path: '$checkins',
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $lookup: {
                from: 'achievements',
                localField: 'checkins.achievementId',
                foreignField: '_id',
                as: 'achievements'
            }
        },
        {
            $unwind: {
                path: '$achievements',
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $lookup: {
                from: 'categories',
                localField: 'achievements.categoryId',
                foreignField: '_id',
                as: 'categories'
            }
        },
        {
            $unwind: {
                path: '$categories',
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $addFields: {
                'achievements.checkinDate': '$checkins.createdAt',
                'achievements.approved': '$checkins.approved',
                'achievements.achievementId': '$achievements._id',
                'achievements.checkinId': '$checkins._id',
                'achievements.categoryId': '$categories._id',
                'checkins.category': '$categories._id'
            }
        },
        {
            $match: {
                $or: [
                    {
                        checkins: {
                            $eq: {}
                        }
                    },
                    {
                        $and: [
                            {
                                'categories.disabled': false
                            },
                            {
                                'checkins.createdAt': {
                                    $gte: new Date(app_settings_1.GlobalYearFilter)
                                }
                            }
                        ]
                    }
                ]
            }
        },
        {
            $group: {
                _id: '$_id',
                userId: {
                    $first: '$_id'
                },
                userName: {
                    $first: '$userName'
                },
                firstName: {
                    $first: '$firstName'
                },
                lastName: {
                    $first: '$lastName'
                },
                passwordReset: {
                    $first: '$passwordReset'
                },
                checkins: {
                    $push: '$achievements'
                }
            }
        },
        {
            $addFields: {
                totalPoints: {
                    $sum: {
                        $map: {
                            input: '$checkins',
                            as: 'item',
                            in: {
                                $cond: [
                                    {
                                        $and: [
                                            {
                                                $eq: ['$$item.approved', true]
                                            }
                                        ]
                                    },
                                    '$$item.points',
                                    0
                                ]
                            }
                        }
                    }
                },
                pendingPoints: {
                    $sum: {
                        $map: {
                            input: '$checkins',
                            as: 'item',
                            in: {
                                $cond: [
                                    {
                                        $and: [
                                            {
                                                $eq: ['$$item.approved', false]
                                            }
                                        ]
                                    },
                                    '$$item.points',
                                    0
                                ]
                            }
                        }
                    }
                }
            }
        }
    ];
}
exports.userWithCheckinsPipeline = userWithCheckinsPipeline;
