"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const multer_1 = require("multer");
const path_1 = require("path");
const dotenv = require("dotenv");
dotenv.config({ path: __dirname + '/../.env' });
exports.dbUrl = process.env.DB_URL;
exports.uploadDir = process.env.UPLOAD_DIR;
exports.publicDir = __dirname + process.env.PUBLIC_DIR;
exports.secret = process.env.SECRET;
exports.ApiIntentHeader = process.env.API_INTENT_HEADER;
exports.OwnsHeader = process.env.OWNS_HEADER;
exports.UploadFileSettings = {
    storage: multer_1.diskStorage({
        destination: exports.uploadDir,
        filename: (req, file, cb) => {
            const randomName = Array(32).fill(null).map(() => (Math.round(Math.random() * 16)).toString(16)).join('');
            const fileName = `${randomName}${path_1.extname(file.originalname)}`;
            cb(null, fileName);
        }
    })
};
