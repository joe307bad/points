"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const multer_1 = require("multer");
const path_1 = require("path");
exports.dbUrl = 'mongodb://localhost:27017/points';
exports.uploadDir = './public/uploads';
exports.secret = '8QnwdhUqb7TgebAwTwpvmBKdFgTE3bFNcDUL3DgTuFDG0';
exports.UploadFileSettings = {
    storage: multer_1.diskStorage({
        destination: exports.uploadDir,
        filename: (req, file, cb) => {
            const randomName = Array(32).fill(null).map(() => (Math.round(Math.random() * 16)).toString(16)).join('');
            cb(null, `${randomName}${path_1.extname(file.originalname)}`);
        }
    })
};
